import{a as e}from"./rolldown-runtime-COnpUsM8.js";import{a as t,c as n,s as r}from"./vendor-motion-CcwqnjDl.js";import{n as i}from"./vendor-react-Bp8z0Hp5.js";import{r as a}from"./layananData-BnMSjOfT.js";import{t as o}from"./useCountUp-BFd-bfDp.js";import{c as s,o as c}from"./wordpressPages-Bh0EJM9a.js";var l=e(n(),1),u=r(),d=`https://wa.me/6281234567890?text=${encodeURIComponent(a.cta.whatsapp)}`,f=`EVENT ORGANIZER ● VENUE MANAGEMENT ● KONSEP KREATIF ● ON-SITE EXECUTION ● DOKUMENTASI PROFESIONAL ● TRIMITRA EVENTS ●`,p=[{value:`250+`,label:`Event Sukses`},{value:`96%`,label:`Tingkat Kepuasan Klien`},{value:`17+`,label:`Kota`},{value:`8+`,label:`Tahun`}];function m({value:e}){let{ref:t,count:n}=o(e);return(0,u.jsx)(`span`,{ref:t,children:n})}function h({text:e,className:n}){return(0,u.jsx)(`h2`,{className:n,children:[{key:`line-0`,delay:.3,content:`Event yang `},{key:`line-1`,delay:.42,content:(0,u.jsx)(`span`,{style:{fontWeight:800},children:`Dikenang,`})},{key:`line-2`,delay:.54,content:`Bukan Sekadar Dihadiri`}].map(e=>(0,u.jsx)(t.span,{initial:{opacity:0,y:18},animate:{opacity:1,y:0},transition:{delay:e.delay,duration:.32,ease:[.22,1,.36,1]},children:e.content},e.key))})}function g(){let[e,n]=(0,l.useState)([]);(0,l.useEffect)(()=>{let e=!1;async function t(){if(s())try{let t=await c({perPage:100,allPages:!0});e||n(t)}catch{e||n([])}}return t(),()=>{e=!0}},[]);let r=(0,l.useMemo)(()=>e.find(e=>e?.category===`Event`&&e?.src)?.src||a.hero.image,[e]);return(0,u.jsxs)(`main`,{className:`meo-panel`,children:[(0,u.jsx)(`style`,{children:`
        .meo-panel{width:100%;min-height:100vh;background:#060d1a;position:relative;font-family:'Inter',system-ui,-apple-system,sans-serif;}
        .meo-close{position:fixed;top:24px;right:24px;z-index:999;width:44px;height:44px;border-radius:100px;border:1px solid rgba(255,255,255,.15);background:rgba(0,0,0,.4);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);color:#fff;display:grid;place-items:center;cursor:pointer;transition:transform .2s ease,background .2s ease}
        .meo-close:hover{transform:scale(1.1);background:rgba(0,0,0,.6)}
        
        .meo-hero{position:relative;min-height:90vh;padding:120px 8% 80px;background:linear-gradient(135deg, #0a6e82 0%, #071320 100%);display:grid;align-items:center;overflow:hidden;}
        .meo-hero::before{content:"";position:absolute;inset:0;background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 400 400' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E");opacity:0.04;pointer-events:none;z-index:1;}
        .meo-grid{position:relative;z-index:2;display:grid;grid-template-columns:1.18fr .82fr;gap:48px;align-items:start;}
        .meo-pill{margin:0;width:fit-content;padding:8px 16px;border-radius:100px;border:0.5px solid rgba(255,255,255,.15);background:rgba(255,255,255,.08);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);color:#fff;font:600 12px/1 'Inter',sans-serif;letter-spacing:.08em}
        .meo-heading{margin:24px 0 16px;color:#fff;font:800 clamp(38px,4.8vw,68px)/1.2 'Plus Jakarta Sans',sans-serif;letter-spacing:-0.02em}
        .meo-heading span{display:inline-block}
        .meo-sub{margin:0;color:#94a3b8;font:500 clamp(15px,1.5vw,20px)/1.5 'Inter',sans-serif;max-width:580px;}
        .meo-desc{margin:12px 0 0;color:#94a3b8;font:400 16px/1.7 'Inter',sans-serif;max-width:580px;}
        .meo-stats{display:grid;grid-template-columns:repeat(4,1fr);margin-top:40px;margin-bottom:40px;}
        .meo-stat{padding:0 24px;border-right:0.5px solid rgba(255,255,255,.1);}
        .meo-stat:first-child{padding-left:0;}
        .meo-stat:last-child{border-right:none;}
        .meo-stat h4{margin:0;color:#fff;font:800 32px/1 'Plus Jakarta Sans',sans-serif}
        .meo-stat p{margin:8px 0 0;color:#64748b;font:500 13px/1.4 'Inter',sans-serif}
        .meo-actions{display:flex;gap:12px;flex-wrap:wrap}
        .meo-btn{display:inline-flex;align-items:center;justify-content:center;padding:14px 28px;border-radius:100px;text-decoration:none;font:600 13px/1 'Inter',sans-serif;letter-spacing:.04em;transition:all 0.2s ease;}
        .meo-btn.sky{background:#38bdf8;color:#0a1628;border:none;}
        .meo-btn.sky:hover{background:#0ea5e9;transform:scale(1.02);}
        .meo-btn.ghost{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.2)}
        .meo-btn.ghost:hover{background:rgba(255,255,255,.05);transform:scale(1.02)}
        .meo-media{position:relative;justify-self:end;width:min(100%,390px);border-radius:20px;overflow:hidden;aspect-ratio:3/4;min-height:0;max-height:520px;transition:transform 0.3s ease;}
        .meo-media:hover{transform:scale(1.02);}
        .meo-media img{width:100%;height:100%;object-fit:cover;display:block}
        .meo-float{position:absolute;top:20px;right:20px;padding:10px 16px;border-radius:100px;background:rgba(10,22,40,.6);border:0.5px solid rgba(255,255,255,.15);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);color:#fff;font:600 12px/1 'Inter',sans-serif;letter-spacing:.04em;}
        
        .meo-marquee{height:52px;background:linear-gradient(90deg, #3b4fd8 0%, #7c3aed 100%);border-top:0.5px solid rgba(255,255,255,.12);border-bottom:0.5px solid rgba(255,255,255,.12);overflow:hidden;display:flex;align-items:center}
        .meo-marquee-track{white-space:nowrap;display:flex;animation:meoMarquee 30s linear infinite;color:#fff;font:500 13px/1 'Inter',sans-serif;letter-spacing:.05em}
        .meo-marquee-track span{padding-right:60px;color:rgba(255,255,255,.4);}
        
        .meo-dark{background:linear-gradient(180deg, #071320 0%, #0a1a2e 100%);padding:120px 8%;}
        .meo-kicker{margin:0;color:rgba(56,189,248,.6);font:600 11px/1 'Inter',sans-serif;letter-spacing:.12em;text-transform:uppercase}
        .meo-title{margin:12px 0 0;color:#fff;font:800 clamp(32px,4.5vw,56px)/1.1 'Plus Jakarta Sans',sans-serif;letter-spacing:-0.02em}
        .meo-grid3{margin-top:40px;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:24px}
        .meo-card{background:rgba(255,255,255,.04);border:0.5px solid rgba(56,189,248,.1);border-radius:16px;padding:28px;transition:all .2s ease}
        .meo-card:hover{background:rgba(56,189,248,.06);border-color:rgba(56,189,248,.3);transform:scale(1.01);}
        .meo-card span{color:rgba(56,189,248,.5);font:500 12px/1 'ui-monospace',SFMono-Regular,Menlo,Monaco,Consolas,monospace}
        .meo-card h4{margin:16px 0 12px;color:#fff;font:700 16px/1.4 'Plus Jakarta Sans',sans-serif;}
        .meo-card p{margin:0;color:#7a9bb5;font:400 14px/1.7 'Inter',sans-serif}
        
        .meo-light{background:linear-gradient(180deg, #e8f4f8 0%, #f0f7fc 100%);padding:120px 8%}
        .meo-light .meo-kicker{color:#0a7a8f;}
        .meo-light .meo-title{color:#0a1628;}
        .meo-connector{width:100%;height:56px;margin-top:48px;}
        .meo-steps{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:16px}
        .meo-step{text-align:center;padding:12px}
        .meo-dot{width:44px;height:44px;border-radius:100px;margin:0 auto 16px;background:linear-gradient(135deg, #e0f2fe, #ede9fe);border:0.5px solid #bae6fd;color:#0a7a8f;display:grid;place-items:center;font:700 14px/1 'ui-monospace',SFMono-Regular,Menlo,monospace;}
        .meo-step h5{margin:0 0 10px;color:#0f172a;font:700 14px/1.4 'Plus Jakarta Sans',sans-serif;}
        .meo-step p{margin:0;color:#64748b;font:400 13px/1.6 'Inter',sans-serif}
        
        .meo-achieve{background:linear-gradient(180deg, #071320 0%, #0f1f38 100%);padding:120px 8%;position:relative;overflow:hidden;}
        .meo-achieve::before{content:"";position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:60vw;height:60vw;background:radial-gradient(circle, rgba(56,189,248,0.06) 0%, transparent 60%);pointer-events:none;}
        .meo-achieve-inner{position:relative;z-index:2;}
        .meo-achieve-grid{margin-top:48px;display:grid;grid-template-columns:repeat(4,minmax(0,1fr));}
        .meo-achieve-card{text-align:center;border-right:0.5px solid rgba(56,189,248,.15);padding:16px 0;}
        .meo-achieve-card:last-child{border-right:none;}
        .meo-achieve-card h4{margin:0;color:#fff;font:800 clamp(52px,6vw,72px)/1 'Plus Jakarta Sans',sans-serif}
        .meo-achieve-card p{margin:12px 0 0;color:#7a9bb5;font:500 13px/1.35 'Inter',sans-serif;text-transform:uppercase;letter-spacing:0.04em}
        
        .meo-cta{background:linear-gradient(180deg, #0a1628 0%, #071022 100%);padding:120px 8%;position:relative;overflow:hidden;}
        .meo-cta::before{content:"";position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:60vw;height:60vw;background:radial-gradient(circle, rgba(56,189,248,0.08) 0%, transparent 60%);pointer-events:none;}
        .meo-cta-inner{position:relative;z-index:1;max-width:640px;margin:0 auto;text-align:center;display:grid;gap:16px;}
        .meo-cta h3{margin:0;color:#fff;font:800 clamp(32px,4.4vw,44px)/1.2 'Plus Jakarta Sans',sans-serif;letter-spacing:-0.02em;}
        .meo-cta p{margin:0 auto;color:#7a9bb5;font:400 16px/1.7 'Inter',sans-serif;max-width:480px;}
        .meo-cta-actions{display:flex;gap:12px;justify-content:center;margin-top:16px;flex-wrap:wrap;}
        
        @keyframes meoMarquee{0%{transform:translateX(0)}100%{transform:translateX(-50%)}}
        @media (max-width:1023px){
            .meo-hero,.meo-dark,.meo-light,.meo-achieve,.meo-cta{padding:80px 6%}
            .meo-media{width:min(100%,340px);max-height:440px}
            .meo-achieve-grid{grid-template-columns:repeat(2,minmax(0,1fr)) !important;}
            .meo-achieve-card{border-right:none !important;border-bottom:0.5px solid rgba(56,189,248,.15) !important;}
            .meo-achieve-card:nth-child(3),.meo-achieve-card:nth-child(4){border-bottom:none !important;}
            .meo-stats{grid-template-columns:repeat(2,1fr) !important;row-gap:24px;}
            .meo-stat{border-right:none !important;padding:0 !important;}
        }
        @media (max-width:768px){
          .meo-close{top:16px;right:16px;width:40px;height:40px;}
          .meo-hero{padding:100px 24px 60px;}
          .meo-grid{grid-template-columns:1fr;gap:40px;}
          .meo-media{order:-1;justify-self:stretch;width:100%;aspect-ratio:3/4;min-height:0;max-height:360px;}
          .meo-media img{height:100%;}
          .meo-dark,.meo-light,.meo-achieve,.meo-cta{padding:64px 24px;}
          .meo-grid3{grid-template-columns:1fr;}
          .meo-connector{display:none;}
          .meo-steps{grid-template-columns:1fr;gap:32px;}
        }
      `}),(0,u.jsx)(i,{to:`/layanan`,className:`meo-close`,"aria-label":`Kembali ke Layanan`,children:(0,u.jsx)(`svg`,{viewBox:`0 0 24 24`,width:`18`,height:`18`,"aria-hidden":`true`,children:(0,u.jsx)(`path`,{fill:`currentColor`,d:`M6.4 5l5.6 5.6L17.6 5 19 6.4 13.4 12 19 17.6 17.6 19 12 13.4 6.4 19 5 17.6 10.6 12 5 6.4z`})})}),(0,u.jsx)(`section`,{className:`meo-hero`,children:(0,u.jsxs)(`div`,{className:`meo-grid`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(t.p,{className:`meo-pill`,initial:{opacity:0,y:18},animate:{opacity:1,y:0},transition:{delay:.15},children:`EVENT ORGANIZER`}),(0,u.jsx)(h,{text:a.hero.heading,className:`meo-heading`}),(0,u.jsx)(t.p,{className:`meo-sub`,initial:{opacity:0,y:18},animate:{opacity:1,y:0},transition:{delay:.5},children:a.hero.subheading}),(0,u.jsx)(t.p,{className:`meo-desc`,initial:{opacity:0,y:18},animate:{opacity:1,y:0},transition:{delay:.6},children:a.hero.description}),(0,u.jsx)(`div`,{className:`meo-stats`,children:a.hero.stats.map((e,n)=>(0,u.jsxs)(t.article,{className:`meo-stat`,initial:{y:20,opacity:0},animate:{y:0,opacity:1},transition:{delay:.65+n*.08},children:[(0,u.jsx)(`h4`,{children:e.value}),(0,u.jsx)(`p`,{children:e.label})]},e.label))}),(0,u.jsxs)(t.div,{className:`meo-actions`,initial:{y:20,opacity:0},animate:{y:0,opacity:1},transition:{delay:.85},children:[(0,u.jsx)(i,{to:`/kontak-kami`,className:`meo-btn sky`,children:`KONSULTASI EVENT`}),(0,u.jsx)(`a`,{href:d,target:`_blank`,rel:`noreferrer`,className:`meo-btn ghost`,children:`HUBUNGI WHATSAPP`})]})]}),(0,u.jsxs)(t.div,{className:`meo-media`,initial:{x:80,opacity:0},animate:{x:0,opacity:1},transition:{delay:.2},children:[(0,u.jsx)(`img`,{src:r,alt:a.hero.heading,loading:`lazy`}),(0,u.jsx)(`span`,{className:`meo-float`,children:`250+ EVENT SUKSES`})]})]})}),(0,u.jsx)(`section`,{className:`meo-marquee`,"aria-label":`Marquee event`,children:(0,u.jsxs)(`div`,{className:`meo-marquee-track`,children:[(0,u.jsx)(`span`,{children:f}),(0,u.jsx)(`span`,{children:f})]})}),(0,u.jsxs)(`section`,{className:`meo-dark`,children:[(0,u.jsx)(t.p,{className:`meo-kicker`,whileInView:{opacity:[0,1],y:[20,0]},viewport:{once:!0,amount:.2},children:`KENAPA TRIMITRA EVENT`}),(0,u.jsx)(t.h3,{className:`meo-title`,whileInView:{opacity:[0,1],y:[20,0]},viewport:{once:!0,amount:.2},children:`Setiap Detail Dipikirkan, Setiap Momen Dirancang`}),(0,u.jsx)(`div`,{className:`meo-grid3`,children:a.keunggulan.map((e,n)=>(0,u.jsxs)(t.article,{className:`meo-card`,initial:{y:30,opacity:0},whileInView:{y:0,opacity:1},viewport:{once:!0,amount:.2},transition:{delay:n*.08},children:[(0,u.jsx)(`span`,{children:e.nomor}),(0,u.jsx)(`h4`,{children:e.judul}),(0,u.jsx)(`p`,{children:e.deskripsi})]},e.nomor))})]}),(0,u.jsxs)(`section`,{className:`meo-light`,children:[(0,u.jsx)(t.p,{className:`meo-kicker`,whileInView:{opacity:[0,1],y:[20,0]},viewport:{once:!0,amount:.2},children:`CARA KERJA`}),(0,u.jsx)(t.h3,{className:`meo-title`,whileInView:{opacity:[0,1],y:[20,0]},viewport:{once:!0,amount:.2},children:`Lima Fase Menuju Event yang Sempurna`}),(0,u.jsxs)(t.svg,{className:`meo-connector`,viewBox:`0 0 1000 56`,preserveAspectRatio:`none`,children:[(0,u.jsx)(`defs`,{children:(0,u.jsxs)(`linearGradient`,{id:`meo-grad-line`,x1:`0%`,y1:`0%`,x2:`100%`,y2:`0%`,children:[(0,u.jsx)(`stop`,{offset:`0%`,stopColor:`rgba(10,122,143,0.15)`}),(0,u.jsx)(`stop`,{offset:`100%`,stopColor:`rgba(79,70,229,0.2)`})]})}),(0,u.jsx)(t.path,{d:`M40 28 H960`,stroke:`url(#meo-grad-line)`,strokeWidth:`2`,fill:`none`,initial:{pathLength:0},whileInView:{pathLength:1},viewport:{once:!0,amount:.2},transition:{duration:1.1,ease:[.22,1,.36,1]}})]}),(0,u.jsx)(`div`,{className:`meo-steps`,children:a.alurKerja.map((e,n)=>(0,u.jsxs)(t.article,{className:`meo-step`,initial:{y:20,opacity:0},whileInView:{y:0,opacity:1},viewport:{once:!0,amount:.2},transition:{delay:n*.08},children:[(0,u.jsx)(`div`,{className:`meo-dot`,children:e.step}),(0,u.jsx)(`h5`,{children:e.judul}),(0,u.jsx)(`p`,{children:e.deskripsi})]},e.step))})]}),(0,u.jsx)(`section`,{className:`meo-achieve`,children:(0,u.jsxs)(`div`,{className:`meo-achieve-inner`,children:[(0,u.jsx)(t.p,{className:`meo-kicker`,whileInView:{opacity:[0,1],y:[20,0]},viewport:{once:!0,amount:.2},children:`PENCAPAIAN`}),(0,u.jsx)(t.h3,{className:`meo-title`,whileInView:{opacity:[0,1],y:[20,0]},viewport:{once:!0,amount:.2},children:`Angka yang Membuktikan Standar Kami`}),(0,u.jsx)(`div`,{className:`meo-achieve-grid`,children:p.map(e=>(0,u.jsxs)(t.article,{className:`meo-achieve-card`,whileInView:{opacity:[0,1],y:[24,0]},viewport:{once:!0,amount:.2},children:[(0,u.jsx)(`h4`,{children:(0,u.jsx)(m,{value:e.value})}),(0,u.jsx)(`p`,{children:e.label})]},e.label))})]})}),(0,u.jsx)(`section`,{className:`meo-cta`,children:(0,u.jsxs)(t.div,{className:`meo-cta-inner`,initial:`hidden`,whileInView:`visible`,viewport:{once:!0,amount:.2},variants:{hidden:{},visible:{transition:{staggerChildren:.12}}},children:[(0,u.jsx)(t.h3,{variants:{hidden:{y:30,opacity:0},visible:{y:0,opacity:1}},children:a.cta.heading}),(0,u.jsx)(t.p,{variants:{hidden:{y:30,opacity:0},visible:{y:0,opacity:1}},children:a.cta.subtext}),(0,u.jsxs)(t.div,{className:`meo-cta-actions`,variants:{hidden:{y:30,opacity:0},visible:{y:0,opacity:1}},children:[(0,u.jsx)(i,{to:`/kontak-kami`,className:`meo-btn sky`,children:`DISKUSIKAN EVENT ANDA`}),(0,u.jsx)(`a`,{href:d,target:`_blank`,rel:`noreferrer`,className:`meo-btn ghost`,children:`CHAT WHATSAPP`})]})]})})]})}export{g as default};